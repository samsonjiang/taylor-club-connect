# 下次继续使用

## 只在本机继续开发

最简单的方式：双击桌面 `TaylorClubConnect-Task\start-taylor-club.bat`。它会启动 Apache、MySQL 和公网隧道。

1. 打开 `E:\AAAWORKHERE\xampp-control.exe`。
2. 点击 Apache 的 `Start`。
3. 点击 MySQL 的 `Start`。
4. 浏览器打开 `http://localhost/taylor-club-connect/`。
5. 代码源文件在桌面的 `TaylorClubConnect-Task\taylor-club-connect` 文件夹中；XAMPP 实际运行的副本在 `E:\AAAWORKHERE\htdocs\taylor-club-connect`。

## 重新生成公网演示链接

保持 Apache 和 MySQL 运行，然后在 PowerShell 执行：

```powershell
& "$env:USERPROFILE\Desktop\TaylorClubConnect-Task\cloudflared.exe" tunnel --url http://localhost:80
```

终端会显示一个新的 `trycloudflare.com` 地址。给老师的完整网址需要在后面加上：

```text
/taylor-club-connect/
```

例如：`https://新的地址.trycloudflare.com/taylor-club-connect/`

不要关闭运行 cloudflared 的 PowerShell 窗口，否则公网链接会失效。Quick Tunnel 每次重启可能生成不同地址。

## 继续改代码

编辑项目源文件后，把变更同步到 XAMPP：

```powershell
Copy-Item '.\*' 'E:\AAAWORKHERE\htdocs\taylor-club-connect' -Recurse -Force
```

如果只是改 PHP/CSS，通常刷新浏览器即可；如果改了 `database.sql`，需要在 phpMyAdmin 或 MySQL 命令行重新执行对应 SQL。
