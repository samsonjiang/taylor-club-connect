<?php
require_once __DIR__ . '/bootstrap.php';
if (current_user()) redirect('dashboard.php');
$error = '';
if (is_post()) {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE email = ?'); $stmt->bind_param('s', $email); $stmt->execute(); $account = $stmt->get_result()->fetch_assoc();
    if ($account && password_verify($password, $account['password_hash'])) { $_SESSION['user_id'] = $account['id']; unset($_SESSION['current_user']); flash('success', 'Welcome back to your campus community.'); redirect('dashboard.php'); }
    $error = 'That email and password combination was not found.';
}
$page_title = 'Log in'; include __DIR__ . '/header.php';
?><main class="auth-shell"><div class="auth-card"><p class="eyebrow">WELCOME BACK</p><h1>Keep the good things going.</h1><p class="auth-intro">Log in to save clubs, join events and see what’s happening around campus.</p><?php if ($error): ?><div class="form-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><label>Email address<input type="email" name="email" required placeholder="you@student.taylors.edu.my"></label><label>Password<input type="password" name="password" required placeholder="Your password"></label><button class="button button-dark button-wide" type="submit">Log in <span>↗</span></button></form><p class="auth-switch">New here? <a href="register.php">Create your account</a></p><p class="demo-note">Demo account: <strong>demo@taylors.edu.my</strong> / <strong>password</strong></p></div></main><?php include __DIR__ . '/footer.php'; ?>
