$ErrorActionPreference = 'Stop'
$xampp = 'E:\AAAWORKHERE'
$cloudflared = Join-Path (Split-Path -Parent $PSScriptRoot) 'cloudflared.exe'
$runtime = Join-Path $xampp 'htdocs\taylor-club-connect'

Write-Host 'Syncing source files to XAMPP...'
Copy-Item (Join-Path $PSScriptRoot '*') $runtime -Recurse -Force

if (-not (Get-NetTCPConnection -State Listen -LocalPort 80 -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath (Join-Path $xampp 'apache_start.bat') -WorkingDirectory $xampp
}
if (-not (Get-NetTCPConnection -State Listen -LocalPort 3306 -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath (Join-Path $xampp 'mysql_start.bat') -WorkingDirectory $xampp
}

Start-Sleep -Seconds 3
Write-Host 'Local site: http://localhost/taylor-club-connect/'
Write-Host 'Starting a public Quick Tunnel. Keep this PowerShell window open.'
$siteOpened = $false
$ErrorActionPreference = 'Continue'
& $cloudflared tunnel --url http://localhost:80 2>&1 | ForEach-Object {
    $line = $_.ToString()
    Write-Host $line
    if (-not $siteOpened -and $line -match 'https://[A-Za-z0-9.-]+\.trycloudflare\.com') {
        $publicBase = $Matches[0]
        $publicSite = "$publicBase/taylor-club-connect/"
        Write-Host ''
        Write-Host '========================================' -ForegroundColor Green
        Write-Host "FULL PUBLIC WEBSITE: $publicSite" -ForegroundColor Green
        Write-Host 'URL copied to clipboard. Opening browser...' -ForegroundColor Green
        Write-Host '========================================' -ForegroundColor Green
        try { Set-Clipboard -Value $publicSite } catch { }
        try { Start-Process $publicSite } catch { Write-Host 'Browser could not be opened automatically; copy the URL above.' -ForegroundColor Yellow }
        $siteOpened = $true
    }
}
