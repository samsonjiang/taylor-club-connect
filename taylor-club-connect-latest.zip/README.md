# Taylor’s Club Connect

Taylor’s Club Connect is a dynamic event and interest-community web application for Taylor’s University Lakeside Campus. It is built for ITS64504 Web Application Programming using HTML, CSS, JavaScript, PHP and MySQL.

## Features

- Browse and filter real Taylor’s club categories and club examples.
- Register, log in, log out and edit a profile using PHP sessions and password hashing.
- Join clubs and events with database-backed many-to-many tables.
- View upcoming events and create new events from a logged-in account.
- Responsive front end with reusable PHP layout components.

## Run in XAMPP

1. Copy this folder into `E:\AAAWORKHERE\htdocs\taylor-club-connect`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin at `http://localhost/phpmyadmin` and import `database.sql`.
4. Open `http://localhost/taylor-club-connect/`.
5. Demo login: `demo@taylors.edu.my` / `password`.

The site uses the official Taylor’s student-life clubs directory and CNS Fest page for the public-facing campus context. Individual event records in the seeded database are prototype data for demonstration.
