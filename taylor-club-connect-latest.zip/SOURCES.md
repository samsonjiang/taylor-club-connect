# Public sources used for the campus context

- Taylor’s University, Clubs, Societies and Sports: https://university.taylors.edu.my/en/student-life/your-taylors-journey/clubs-societies-and-sports.html
- Taylor’s University, Clubs and Societies Festival 2026: https://university.taylors.edu.my/en/student-life/events/cns-fest.html
- Taylor’s University, Social Media Directory: https://university.taylors.edu.my/en/get-in-touch/contact-information/social-media-directory.html

The club names, categories and descriptions in the seed data are adapted from the official student-life directory. The events are prototype records created for the assignment demonstration, not claims that the university has published those exact event details.
