<?php
require_once __DIR__ . '/bootstrap.php';
$user = current_user();
$page_title = $page_title ?? 'Taylor’s Club Connect';
?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?> · Taylor’s Club Connect</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="index.php"><span class="brand-mark">T</span><span>Taylor’s <strong>Club Connect</strong></span></a>
        <nav class="main-nav" aria-label="Main navigation">
            <a href="index.php">Explore</a>
            <a href="index.php#clubs">Clubs</a>
            <a href="index.php#events">Events</a>
            <?php if ($user): ?>
                <a href="dashboard.php">My space</a>
                <a class="nav-user" href="profile.php"><span class="mini-avatar" style="--avatar:<?= e($user['avatar_color']) ?>"><?= e(initials($user['name'])) ?></span><?= e(explode(' ', $user['name'])[0]) ?></a>
            <?php else: ?>
                <a class="button button-small button-outline" href="login.php">Log in</a>
            <?php endif; ?>
        </nav>
        <button class="menu-toggle" aria-label="Toggle menu">☰</button>
    </div>
</header>
<?php if ($message = flash('success')): ?><div class="flash success container"><?= e($message) ?></div><?php endif; ?>
<?php if ($message = flash('error')): ?><div class="flash error container"><?= e($message) ?></div><?php endif; ?>
