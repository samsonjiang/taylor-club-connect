<footer class="site-footer">
    <div class="container footer-grid">
        <div><a class="brand footer-brand" href="index.php"><span class="brand-mark">T</span><span>Taylor’s <strong>Club Connect</strong></span></a><p>A student-built hub for finding your people at Taylor’s University Lakeside Campus.</p></div>
        <div><h4>Explore</h4><a href="index.php#clubs">Clubs & societies</a><a href="index.php#events">Upcoming events</a><a href="create_event.php">Create an event</a></div>
        <div><h4>Official links</h4><a target="_blank" rel="noreferrer" href="https://university.taylors.edu.my/en/student-life/your-taylors-journey/clubs-societies-and-sports.html">Taylor’s clubs page ↗</a><a target="_blank" rel="noreferrer" href="https://university.taylors.edu.my/en/student-life/events/cns-fest.html">CNS Fest 2026 ↗</a><a href="mailto:seal@taylors.edu.my">Student Development ↗</a></div>
    </div>
    <div class="container footer-bottom"><span>Built for the WAP group assignment · ITS64504</span><span>Taylor’s Lakeside Campus, Subang Jaya</span></div>
</footer>
<script src="assets/app.js"></script>
</body>
</html>
