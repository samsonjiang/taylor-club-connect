<?php
require_once __DIR__ . '/bootstrap.php';
$page_title = 'Find your people';
$category = trim($_GET['category'] ?? '');
$search = trim($_GET['q'] ?? '');
$categories = db()->query('SELECT DISTINCT category FROM clubs ORDER BY category')->fetch_all(MYSQLI_ASSOC);
$where = [];
$types = '';
$params = [];
if ($category !== '') { $where[] = 'category = ?'; $types .= 's'; $params[] = $category; }
if ($search !== '') { $where[] = '(name LIKE ? OR description LIKE ? OR category LIKE ?)'; $types .= 'sss'; $like = '%' . $search . '%'; $params = array_merge($params, [$like, $like, $like]); }
$sql = 'SELECT c.*, (SELECT COUNT(*) FROM memberships m WHERE m.club_id = c.id) AS member_count FROM clubs c';
if ($where) { $sql .= ' WHERE ' . implode(' AND ', $where); }
$sql .= ' ORDER BY featured DESC, name';
$stmt = db()->prepare($sql);
if ($types) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$clubs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$events = db()->query("SELECT e.*, c.name AS club_name, c.color AS club_color, (SELECT COUNT(*) FROM event_attendees a WHERE a.event_id = e.id) AS attendee_count FROM events e JOIN clubs c ON c.id = e.club_id WHERE e.starts_at >= NOW() ORDER BY e.starts_at LIMIT 4")->fetch_all(MYSQLI_ASSOC);
$club_images = [
    'Performing arts' => 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=900&q=85',
    'Cultural society' => 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=900&q=85',
    'Business & tech' => 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=85',
    'Community centric' => 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=900&q=85',
    'International clubs' => 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=900&q=85',
    'Sports & games' => 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=85',
];
include __DIR__ . '/header.php';
?>
<main>
    <section class="hero container">
        <div class="hero-copy"><p class="eyebrow">TAYLOR’S UNIVERSITY · LAKESIDE CAMPUS</p><h1>Find your people.<br><em>Make it yours.</em></h1><p class="hero-text">Discover student clubs, meetups and events that make campus life feel like home. From music and culture to sports and social impact, there’s a place for every interest.</p><div class="hero-actions"><a class="button" href="#clubs">Explore clubs <span>↗</span></a><a class="text-link" href="#events">See upcoming events <span>↓</span></a></div></div>
        <div class="hero-art" aria-label="Taylor's University students enjoying campus life"><div class="hero-photo"></div><div class="hero-caption"><strong>Good company starts here.</strong><span>Find your kind of campus life.</span></div></div>
    </section>
    <section class="stats-band"><div class="container stats"><div><strong>100+</strong><span>clubs & societies</span></div><div><strong>7</strong><span>ways to get involved</span></div><div><strong>1</strong><span>campus community</span></div><div class="stats-note">Inspired by the official Taylor’s student-life directory.</div></div></section>
    <section class="section container" id="clubs"><div class="section-heading"><div><p class="eyebrow">BROWSE BY INTEREST</p><h2>Where do you belong?</h2></div><p>Find a club that matches your energy, then show up to an event and start something new.</p></div>
        <form class="filters" method="get"><div class="search-wrap"><span>⌕</span><input name="q" value="<?= e($search) ?>" placeholder="Search clubs, interests or keywords…"></div><select name="category"><option value="">All categories</option><?php foreach ($categories as $item): ?><option <?= $category === $item['category'] ? 'selected' : '' ?> value="<?= e($item['category']) ?>"><?= e($item['category']) ?></option><?php endforeach; ?></select><button class="button button-dark" type="submit">Filter</button></form>
        <div class="club-grid"><?php foreach ($clubs as $club): $club_image = $club_images[$club['category']] ?? $club_images['International clubs']; ?><article class="club-card" style="--club:<?= e($club['color']) ?>"><div class="club-card-media" style="background-image:url('<?= e($club_image) ?>')"><span class="club-icon"><?= e($club['icon']) ?></span></div><div class="club-card-body"><div class="club-top"><span class="club-category"><?= e($club['category']) ?></span></div><h3><?= e($club['name']) ?></h3><p><?= e($club['description']) ?></p><div class="card-meta"><span><?= (int)$club['member_count'] + (int)$club['seed_members'] ?> members</span><a href="club.php?id=<?= (int)$club['id'] ?>">View club <span>↗</span></a></div></div></article><?php endforeach; ?></div>
    </section>
    <section class="section section-tint" id="events"><div class="container"><div class="section-heading"><div><p class="eyebrow">WHAT’S HAPPENING</p><h2>Upcoming on campus</h2></div><a class="text-link" href="events.php">View all events <span>↗</span></a></div><div class="event-list"><?php foreach ($events as $event): ?><article class="event-row"><div class="date-tile"><strong><?= date('d', strtotime($event['starts_at'])) ?></strong><span><?= strtoupper(date('M', strtotime($event['starts_at']))) ?></span></div><div class="event-info"><span class="tag" style="--tag:<?= e($event['club_color']) ?>"><?= e($event['club_name']) ?></span><h3><?= e($event['title']) ?></h3><p><?= e(event_time($event['starts_at'])) ?> · <?= e($event['location']) ?></p></div><div class="event-attendees"><strong><?= (int)$event['attendee_count'] + (int)$event['seed_attendees'] ?></strong><span>going</span></div><a class="arrow-link" href="event.php?id=<?= (int)$event['id'] ?>">↗</a></article><?php endforeach; ?></div></div></section>
    <section class="join-cta container"><div><p class="eyebrow">YOUR CAMPUS, YOUR CALL</p><h2>Have an idea worth sharing?</h2><p>Bring your community together. Create an event and invite Taylor’s students to join in.</p></div><a class="button" href="create_event.php">Create an event <span>↗</span></a></section>
</main>
<?php include __DIR__ . '/footer.php'; ?>
