document.querySelector('.menu-toggle')?.addEventListener('click',()=>document.querySelector('.main-nav').classList.toggle('is-open'));
