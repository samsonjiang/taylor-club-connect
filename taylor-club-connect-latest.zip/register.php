<?php
require_once __DIR__ . '/bootstrap.php';
if (current_user()) redirect('dashboard.php');
$errors = [];
if (is_post()) {
    $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $programme = trim($_POST['programme'] ?? ''); $password = $_POST['password'] ?? '';
    if (strlen($name) < 2) $errors[] = 'Please enter your name.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email.';
    if (strlen($password) < 6) $errors[] = 'Your password needs at least 6 characters.';
    if (!$errors) { $hash = password_hash($password, PASSWORD_DEFAULT); $colors = ['#efb66c','#f27a6a','#7ec8be','#8d8ae8']; $color = $colors[array_rand($colors)]; $stmt = db()->prepare('INSERT INTO users (name,email,password_hash,programme,avatar_color) VALUES (?,?,?,?,?)'); $stmt->bind_param('sssss', $name,$email,$hash,$programme,$color); try { $stmt->execute(); $_SESSION['user_id'] = db()->insert_id; flash('success', 'Your profile is ready. Welcome to Club Connect.'); redirect('dashboard.php'); } catch (mysqli_sql_exception $e) { $errors[] = 'That email is already registered.'; } }
}
$page_title = 'Create account'; include __DIR__ . '/header.php';
?><main class="auth-shell"><div class="auth-card"><p class="eyebrow">MAKE YOUR MARK</p><h1>Start with an interest.</h1><p class="auth-intro">Create a profile to join the Taylor’s clubs and events that feel like you.</p><?php if ($errors): ?><div class="form-error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?><form method="post" class="form-stack"><label>Full name<input name="name" required value="<?= e($_POST['name'] ?? '') ?>" placeholder="Your name"></label><label>Student email<input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>" placeholder="you@student.taylors.edu.my"></label><label>Programme or school<input name="programme" value="<?= e($_POST['programme'] ?? '') ?>" placeholder="e.g. Bachelor of Computer Science"></label><label>Password<input type="password" name="password" required placeholder="At least 6 characters"></label><button class="button button-dark button-wide" type="submit">Create my profile <span>↗</span></button></form><p class="auth-switch">Already have an account? <a href="login.php">Log in</a></p></div></main><?php include __DIR__ . '/footer.php'; ?>
